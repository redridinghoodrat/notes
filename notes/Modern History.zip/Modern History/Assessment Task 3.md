#### Back to [[Modern History]]

##### Information from [[Shaping of the Modern World WW1]]

