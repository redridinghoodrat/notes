Historical issues:

- At the conception of the series, *Queen Elizabeth* was alive and ruling- did this series raise ethical issues as it may influence the public opinion on a living and very powerful person?
- Now that she has passed, how might the Crown be a source of information: for Britain's history, the royal family or even British identity?
- Given the current and ongoing debates over whether countries like Australia should become a Republic, could the popularity of this series and a favourable depiction of the royal family influence political decisions?
