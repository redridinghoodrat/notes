#### Back to [[Modern History]]
##### Information from [[The Cuban Revolution]]