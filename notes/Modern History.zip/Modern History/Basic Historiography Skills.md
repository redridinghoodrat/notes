#### Back to [[Modern History]] and [[Ancient History]]

Historiography is the 