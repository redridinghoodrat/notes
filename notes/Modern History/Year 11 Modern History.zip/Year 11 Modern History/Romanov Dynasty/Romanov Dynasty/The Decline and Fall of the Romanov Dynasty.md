#### Back to [[Year 11 Modern History]]

[[Assessment Task 1]]

## Introduction

| What do you see?                                                                                                                     | What do you think?                                         |
| ------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------- |
| Rasputin, Tsar Nicholas II and Tsarina Alexandra sitting in a circle with the large Rasputin's hands wrapping around the two of them | Implies that Rasputin had great influence withinthe royals |

### [[Context of the Romanov Dynasty]]

The Romanov Dynasty was the first consistent government over the Russian people, during a period of great instability and infighting with other cultures. The dynasty began with the tsar Michael I in 1607. 
