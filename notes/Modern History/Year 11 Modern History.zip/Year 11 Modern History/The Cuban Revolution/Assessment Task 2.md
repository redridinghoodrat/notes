#### Back to [[Year 11 Modern History]]
##### Information from [[The Cuban Revolution]]

